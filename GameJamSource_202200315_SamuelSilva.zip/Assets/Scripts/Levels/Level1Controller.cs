

public class Level1Controller : BaseLevelController
{

    void Start()
    {
       StartLevel();
    }

    public override void StartLevel()
    {
        base.StartLevel();
    }
    
}